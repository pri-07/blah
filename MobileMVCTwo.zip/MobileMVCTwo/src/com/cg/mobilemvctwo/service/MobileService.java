package com.cg.mobilemvctwo.service;

import java.util.List;

import com.cg.mobilemvctwo.dto.Mobile;

public interface MobileService {

	public List<Mobile> showAllMobile();

}
