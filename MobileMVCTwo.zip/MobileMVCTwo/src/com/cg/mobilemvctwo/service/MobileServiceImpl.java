package com.cg.mobilemvctwo.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mobilemvctwo.dao.MobileDao;
import com.cg.mobilemvctwo.dto.Mobile;

@Service("mobileservice")
@Transactional
class MobileServiceImpl implements MobileService{
	
	@Autowired
	MobileDao mobiledao;
	

	@Override
	public List<Mobile> showAllMobile() {
		// TODO Auto-generated method stub
		return mobiledao.showAllMobile();
	}

}
