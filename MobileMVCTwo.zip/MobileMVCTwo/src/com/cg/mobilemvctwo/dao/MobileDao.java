package com.cg.mobilemvctwo.dao;

import java.util.List;

import com.cg.mobilemvctwo.dto.Mobile;

public interface MobileDao {

	public List<Mobile> showAllMobile();

}
