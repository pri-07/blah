package com.cg.ems.test;
import com.cg.ems.exception.EmployeeException;
import static org.junit.Assert.*;
import junit.framework.Assert;

import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;



import org.junit.Test;


public class EmployeeTest {
	
	//NAME
	@Test (expected=NullPointerException.class)
	public void test_ValidateName_null() throws EmployeeException{
		EmployeeService service=new EmployeeServiceImpl();
		service.validateName(null);
	}
	@Test
	public void test_validateName_v1() throws EmployeeException{
	
		String name="Aete121";
		EmployeeService service=new EmployeeServiceImpl();
		boolean result= service.validateName(name);
		Assert.assertEquals(false,result);
	}
	@Test
	public void test_validateName_v2() throws EmployeeException{
	
		String name="Amita";
		EmployeeService service=new EmployeeServiceImpl();
		boolean result= service.validateName(name);
		Assert.assertEquals(true,result);
	}
	@Test
	public void test_validateName_v3() throws EmployeeException{
	
		String name="amita";
		EmployeeService service=new EmployeeServiceImpl();
		boolean result= service.validateName(name);
		Assert.assertEquals(false,result);
	}
	
	
	//PROJECTNAME
		@Test (expected=NullPointerException.class)
		public void test_ValidateProject_null() throws EmployeeException{
			EmployeeService service=new EmployeeServiceImpl();
			service.validateProjname(null);
		}
		@Test
		public void test_validateProject_v1() throws EmployeeException{
		
			String projname="J1av34";
			EmployeeService service=new EmployeeServiceImpl();
			boolean result= service.validateProjname(projname);
			Assert.assertEquals(false,result);
		}
		@Test
		public void test_validateProject_v2() throws EmployeeException{
		
			String projname="Java";
			EmployeeService service=new EmployeeServiceImpl();
			boolean result= service.validateProjname(projname);
			Assert.assertEquals(true,result);
		}
		@Test
		public void test_validateProject_v3() throws EmployeeException{
		
			String name="java";
			EmployeeService service=new EmployeeServiceImpl();
			boolean result= service.validateName(name);
			Assert.assertEquals(false,result);
		}
		
		
		//Salary
		@Test (expected=NullPointerException.class)
		public void test_ValidateSalary_null() throws EmployeeException{
			EmployeeService service=new EmployeeServiceImpl();
			service.validateSalary(null);
		}
		@Test
		public void test_validateSalary_v1() throws EmployeeException{
		
			double salary=123;
			EmployeeService service=new EmployeeServiceImpl();
			boolean result= service.validateSalary(salary);
			Assert.assertEquals(false,result);
		}
		@Test
		public void test_validateSalary_v2() throws EmployeeException{
		
			double salary=10000.75;
			EmployeeService service=new EmployeeServiceImpl();
			boolean result= service.validateSalary(salary);
			Assert.assertEquals(true,result);
		}
		@Test
		public void test_validateSalary_v3() throws EmployeeException{
		
			Double salary=1000.09607;
			EmployeeService service=new EmployeeServiceImpl();
			boolean result= service.validateSalary(salary);
			Assert.assertEquals(false,result);
		}
	
	

}




