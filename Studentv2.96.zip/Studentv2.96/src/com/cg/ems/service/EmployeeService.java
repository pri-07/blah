package com.cg.ems.service;


import java.util.ArrayList;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;

public interface EmployeeService {
	
	public int addEmployee(Employee emp);
	public Employee displayEmployee(int empid);
	public Employee updateEmployee(Employee emp);
	public ArrayList<Employee> searchEmployeeProj(String projname);
	public ArrayList<Employee> searchEmployeeSal(double salary);
	
	public Employee validateDetails(Employee e) throws EmployeeException;
	public boolean validateName(String name) throws EmployeeException;
	public boolean validateSalary(Double salary);
	public boolean validateProjname(String projname);
	
	

	
	
	
}
