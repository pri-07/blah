package com.cg.ems.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;


public class MainMethod {
	
	public static void main(String[] args) 
	{
	
		Employee emp=new Employee();
		EmployeeService service=new EmployeeServiceImpl();
		
		Scanner sc=new Scanner(System.in);
		int ch=0;
		
		do{		
		System.out.println("-=-=-=-=-=-=-=Menu=-=-=-=-=-=-=-=-=-=-=-");
		System.out.println("1.Add Employee");
		System.out.println("2.Display employee details");
		System.out.println("3.Update details");
		System.out.println("4.Search employees on basis of project");
		System.out.println("5.Search employees on basis of salary");
		System.out.println("6.Exit");
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
		System.out.println("Enter your choice:");
		ch=sc.nextInt();
		
		switch(ch)
		{
		
		case 1: 
		do {
				
			System.out.println("Enter employee name:");
			String name=sc.next();
	
			System.out.println("Enter employee salary:");
			Double salary=sc.nextDouble();
			
			System.out.println("Enter project name:");
			String projname=sc.next();
		
			emp.setName(name);
			emp.setSalary(salary);
			emp.setProjname(projname);
			try
			{
				if(service.validateDetails(emp)!=null)
					break;
				else
					System.out.println("Invalid details,Please try again");
			}
			catch(Exception e)
			{
				System.err.println(e.getMessage());
			}
			
		}while(true);
		
		int empid=service.addEmployee(emp);
		System.out.println("Employee record added:"+empid);
		break;
		
		case 2:
			System.out.println("Enter employee id:");
			empid=sc.nextInt();
			
			emp=service.displayEmployee(empid);
			
			if(emp==null)
			{
				System.out.println("Employee record not found . . . . ");
			}
			else
			{
				System.out.println(emp.getName());
				System.out.println(emp.getProjname());
				System.out.println(emp.getSalary());

			}
			break;
			
		case 3:
			System.out.println("Enter employee id:");
			empid=sc.nextInt();
			emp=service.displayEmployee(empid);
	
					if(emp==null)
					{
						System.out.println("Employee record not found . . . . ");
					}
					else
					{
						System.out.println("Enter new salary");
						Double salarynew=sc.nextDouble();
						emp.setSalary(salarynew);
						
						emp=service.updateEmployee(emp);
						System.out.println("Employee salary revised");
						
						System.out.println("EmployeeID  "+  "Name  "+"  Project  "+"  Salary  ");
						System.out.println(emp.getEmpid()+"		"+emp.getName()+"	"+emp.getProjname()+"	"+emp.getSalary());
						
					}
					break;
					
		case 4:
			String projname ;
			
			do
			{
			
				System.out.println("Enter project name");
				projname=sc.next();
			try
			{
				if((service.validateProjname(projname)))
				{
					break;
				}
				else
					System.out.println("Invalid project name,try again");
			}
				catch(Exception e)
				{
					System.err.println(e.getMessage());
				}
			}
			while(true);
			
	
				ArrayList<Employee> list=service.searchEmployeeProj(projname);
			
				if(list.size()==0)
				{
					System.out.println("No employee assigned to project");
				}
				else
				{
					for(Employee e:list)
					{
						System.out.println(e.getEmpid()+" "+e.getName()+" "+e.getSalary());
					}
				}
				break;
			
			
		case 5:
			System.out.println("Enter employee salary");
			double salary=sc.nextDouble();
	
			ArrayList<Employee> listsal=service.searchEmployeeSal(salary);
	
			if(listsal.size()==0)
			{
				System.out.println("No employee with given salary");
			}
			else
			{
				for(Employee e:listsal)
				{
					System.out.println(e.getEmpid()+" "+e.getName()+" "+e.getSalary());
				}
			}
			break;
		
		}//end of switch
		
	}while(ch!=6); //end of do-while
	System.out.println("End of application");
	}

}