package com.cg.ems.dao;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import com.cg.ems.dto.Employee;

public class EmployeeDAOImpl implements EmployeeDAO{

	Employee emp;
	Map<Integer,Employee> empMap;
	public EmployeeDAOImpl()
	{
		empMap=DataStore.createCollection();
	}
	
	@Override
	public int addEmployee(Employee emp) {
			int empid=(int) (1000*Math.random());
			emp.setEmpid(empid);
			empMap.put(empid,emp);
		
		return empid;
	}

	@Override
	public Employee displayEmployee(int empid) {
		Employee emp=empMap.get(empid);
		return emp;
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		empMap.put(emp.getEmpid(), emp);
		return emp;
	}

	@Override
	public ArrayList<Employee> searchEmployeeProj(String projname) {
		Collection<Employee> empList=empMap.values();
		ArrayList<Employee> employees=new ArrayList<Employee>();
			
			for(Employee e:empList)
			{
				if(e.getProjname().equals(projname))
				{
					employees.add(e);
				}
			}
			return employees;
	}

	@Override
	public ArrayList<Employee> searchEmployeeSal(Double salary) {
		Collection<Employee> empList=empMap.values();
		ArrayList<Employee> employees=new ArrayList<Employee>();
			
			for(Employee e:empList)
			{
				if(e.getProjname().equals(salary))
				{
					employees.add(e);
				}
			}
			return employees;
	}
}