package com.cg.ems.dao;

import java.util.ArrayList;

import com.cg.ems.dto.Employee;


public interface EmployeeDAO {
	

	public int addEmployee(Employee emp);
	public Employee displayEmployee(int empid);
	public Employee updateEmployee(Employee emp);
	public ArrayList<Employee> searchEmployeeProj(String projname);
	public ArrayList<Employee> searchEmployeeSal(Double salary);
	
}