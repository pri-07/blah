package com.cg.ems.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.ems.dto.Employee;

public class DataStore {
	
	private static Map<Integer,Employee> empcoll;
	public static Map<Integer,Employee> createCollection()
	{
		if(empcoll==null)
			empcoll=new HashMap<>();
		return empcoll;
	}

	
}