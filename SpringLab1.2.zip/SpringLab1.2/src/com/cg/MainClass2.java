package com.cg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.Employee;

public class MainClass2 {
	
	public static void main(String[] args) {
	ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
		
		SBU sbu=(SBU) app.getBean("sbu");
		Employee employee=(Employee) app.getBean("emp");
	
		System.out.println(employee);
		employee.getSbuDetails();
		
	}

}
