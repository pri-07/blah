package com.cg;

public class Employee extends SBU {
	
	int employeeId;
	String employeeName;
	double salary;
	SBU businessUnit=new SBU();
	
	

	public void setBusinessUnit(SBU businessUnit) {
		this.businessUnit = businessUnit;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", salary=" + salary +"]";
	}

	public void getSbuDetails()
	{
		System.out.println("SBU [sbuInt=" + businessUnit.getSbuInt() + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead +"]" );
		
	}
}
