package com.cg;

public class SBU {
	int sbuInt;
	String sbuName;
	String sbuHead;
	
	
	public void setSbuInt(int sbuInt) {
		this.sbuInt = sbuInt;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public int getSbuInt() {
		return sbuInt;
	}
	public String getSbuName() {
		return sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	
}
