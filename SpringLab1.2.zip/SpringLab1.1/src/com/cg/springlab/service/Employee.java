package com.cg.springlab.service;

public class Employee {

	
	//instance variables
	int employeeId;
	String employeeName;
	double salary;
	String businessUnit;
	int age;
	
	
	//setters
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	@Override
	public String toString() {
		return "Employee Id=" + employeeId  + "\nEmployee Name=" + employeeName + "\nEmployee Salary =" + salary
				+ "\nEmployee BU=" + businessUnit + "\nEmployee age=" + age + " ";
	}
	
	
	
	
}
