package com.cg.springone.service;

public class Circle implements Shape{
	String radius; //instance variables
	
	
	public void setRadius(String radius) {
		this.radius = radius;
	}


	@Override
	public void getShape() {
	System.out.println("In Circle"+radius);
		
	}


	
}
