package com.cg.springone.service;

public interface Shape {
	
	public void getShape();
}
