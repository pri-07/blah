package com.cg.springone.ui;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springone.service.Mobile;
import com.cg.springone.service.Shape;

public class MyApplication {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");

//		Shape sp=(Shape) app.getBean("cir");
//		
//		sp.getShape();
		
		System.out.println("Enter mobId:");
		int mobid=sc.nextInt();
		Mobile mobile=(Mobile) app.getBean("mob");
		mobile.setMobId(mobid);
	
		
		mobile.setMobName("LG");
		mobile.getAllDetail();
		
	}
}
