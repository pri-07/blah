package com.cg.mytest.service;

import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Input:");
		
		String str=sc.next();
		Shape shape=Shapeinfo.showShape(str);
		shape.getShape();
	}
}
