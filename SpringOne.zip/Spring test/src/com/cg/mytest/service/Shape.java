package com.cg.mytest.service;

public interface Shape {
	public void getShape();
}
