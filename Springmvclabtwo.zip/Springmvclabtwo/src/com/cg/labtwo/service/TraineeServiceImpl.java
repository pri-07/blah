package com.cg.labtwo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.labtwo.dao.TraineeDao;
import com.cg.labtwo.dao.TraineeDaoImpl;
import com.cg.labtwo.dto.Trainee;


@Service("traineeservice")
@Transactional
public class TraineeServiceImpl implements TraineeService{
	
	@Autowired
	TraineeDao traineedao;

	public void addTrainee(Trainee trainee) {
		traineedao.addTrainee(trainee);
		
	}

	@Override
	public void delTrainee(int traineeId) {
		// TODO Auto-generated method stub
		traineedao.delTrainee(traineeId);
		
	}

	@Override
	public Trainee modTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return traineedao.modTrainee(trainee);
	}


	
	public List<Trainee> showAll()
	{
		List<Trainee> all=traineedao.showAll();
		return all;
	}

	@Override
	public Trainee retTrainee(int traineeId) {
		// TODO Auto-generated method stub
		return traineedao.retTrainee(traineeId);
	}


}
