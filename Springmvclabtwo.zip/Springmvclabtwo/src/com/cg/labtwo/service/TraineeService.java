package com.cg.labtwo.service;

import java.util.List;

import com.cg.labtwo.dto.Trainee;

public interface TraineeService {
	public void addTrainee(Trainee trainee);

	public void delTrainee(int traineeId);
	
	public Trainee modTrainee(Trainee trainee);

	public Trainee retTrainee(int traineeId);

	public List<Trainee> showAll();
}
