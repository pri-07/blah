package com.cg.labtwo.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Trainee")
public class Trainee {
	
	@Id
	@Column(name="traineeId")
	int traineeId;
	
	@Column(name="traineeLocation")
	String traineeLocation;
	
	@Column(name="traineeName")
	String traineeName;
	
	@Column(name="traineeDomain")
	String traineeDomain;
	
	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeLocation="
				+ traineeLocation + ", traineeName=" + traineeName
				+ ", traineeDomain=" + traineeDomain + "]";
	}
	//getters and setters
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}

	//constructors
	public Trainee() {
		super();
	}
	
	
	public Trainee(int traineeId, String traineeLocation, String traineeName,
			String traineeDomain) {
		super();
		this.traineeId = traineeId;
		this.traineeLocation = traineeLocation;
		this.traineeName = traineeName;
		this.traineeDomain = traineeDomain;
	}
	
	

}
