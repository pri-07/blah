package com.cg.labtwo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.labtwo.dto.Trainee;



@Repository("traineedao")
public class TraineeDaoImpl implements TraineeDao{
	@PersistenceContext
	EntityManager em;

	public void addTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		em.persist(trainee);
		em.flush();
	}

	@Override
	public void delTrainee(int traineeId) {
		// TODO Auto-generated method stub
		Query queryDelete=em.createQuery("delete FROM Trainee where traineeId=:tdelete");
		queryDelete.setParameter("tdelete", traineeId);
		queryDelete.executeUpdate();
		
	}




	@Override
	public Trainee modTrainee(Trainee trainee) {
		Query queryUpdate=em.createQuery("update Trainee set traineeId=:tid,traineeDomain=:tdom,traineeName=:tname,traineeLocation=:tloc where traineeId=:tid");
		queryUpdate.setParameter("tid", trainee.getTraineeId());
		queryUpdate.setParameter("tname", trainee.getTraineeName());
		queryUpdate.setParameter("tdom", trainee.getTraineeDomain());
		queryUpdate.setParameter("tloc",trainee.getTraineeLocation());
		queryUpdate.executeUpdate();
		return trainee;
	}

	

	@Override
	public List<Trainee> showAll() {
		// TODO Auto-generated method stub
		Query query=em.createQuery("FROM Trainee");
		List<Trainee> myAll=query.getResultList();
		return myAll;
	}

	@Override
	public Trainee retTrainee(int traineeId) {
		// TODO Auto-generated method stub
		Query querySearch=em.createQuery("FROM Trainee where traineeId=:tid");
		querySearch.setParameter("tid", traineeId);
		Trainee all=(Trainee) querySearch.getSingleResult();
		return all;
	}
}
