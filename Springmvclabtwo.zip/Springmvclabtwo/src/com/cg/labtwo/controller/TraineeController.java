package com.cg.labtwo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.labtwo.dto.Trainee;
import com.cg.labtwo.service.TraineeService;
import com.cg.labtwo.service.TraineeServiceImpl;



@Controller
public class TraineeController {
	
	@Autowired
	TraineeService traineeservice;
	
	@RequestMapping(value="/home")
	public String login(@ModelAttribute ("log") Trainee t)
	{
		return "login";
	}
	
	@RequestMapping(value="tms")
	public String menu()
	{
		return "menu";
	}
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addTrainee(@ModelAttribute("my") Trainee trainee,Map<String,Object> model)
	{
		List<String> myList=new ArrayList<>();
		myList.add("Java");
		myList.add("SAP");
		myList.add("BI");
		model.put("value", myList);
		return "addt";
	}
	
	@RequestMapping(value="addmsg",method=RequestMethod.POST)
	public String dispAdd(@ModelAttribute("my") Trainee trainee)
	{
		traineeservice.addTrainee(trainee);
	//	System.out.println(trainee);
		return "addmessage";
	}
	
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String deletePage(@ModelAttribute("del") Trainee trainee)
	{
		return "getdelete";
	}
	
	@RequestMapping(value="delinfo",method=RequestMethod.POST)
	public String delTrainee(@ModelAttribute("del") Trainee trainee)
	{
		traineeservice.delTrainee(trainee.getTraineeId());
	//	System.out.println(trainee);
		return "delresult";
	}
	
	
	@RequestMapping(value="modify",method=RequestMethod.GET)
	public String modifyPage(@ModelAttribute("mod") Trainee trainee)
	{
		return "getmodify";
	}
	
	@RequestMapping(value="modinfo",method=RequestMethod.POST)
	public String modTrainee(@ModelAttribute("mod") Trainee trainee)
	{
		traineeservice.modTrainee(trainee);
	//	System.out.println(trainee);
		return "modresult";
	}
	
	

	@RequestMapping(value="retrieve",method=RequestMethod.GET)
	public String retrievePage(@ModelAttribute("ret") Trainee trainee)
	{
		return "getr";
	}
	
	
	@RequestMapping(value="rone",method=RequestMethod.POST)
	public ModelAndView dataSearch(@ModelAttribute("ret") Trainee trainee)
	{
		
		Trainee abc=traineeservice.retTrainee(trainee.getTraineeId());
		//System.out.println(mobSearch);
		return new ModelAndView("showsearch","temp",abc);
		//incomplete showsearch
	}
	
	
	@RequestMapping(value="retrieveall",method=RequestMethod.GET)
	public ModelAndView showAllMobileData()
	{
		List<Trainee> all=traineeservice.showAll();
		//System.out.println(allMobile); to check if values appear on console
		return new ModelAndView("alltrainee", "data", all);
		
	}
	
	
}
